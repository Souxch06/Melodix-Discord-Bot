# Melodix Discord Bot

Bot Discord du serveur Melodix : configuration automatique du serveur, tickets de support, commandes slash et journaux d'activité.

Stack : Node.js 20+, Discord.js v14, ES Modules, dotenv. Aucun service payant requis.

## Fonctionnalités

- **Setup idempotent** (`/setup`) : crée rôles, catégories et salons définis dans `src/config/layout.js`. Relancer la commande ne crée aucun doublon.
- **Messages automatiques** : règlement, à-propos, FAQ, guide, premium, liens officiels, panneau de tickets. Chaque message est publié une seule fois (repéré par une référence en pied d'embed).
- **Tickets** : bouton d'ouverture, salon privé par membre, un seul ticket ouvert à la fois, fermeture par bouton ou `/close`, logs de création et fermeture.
- **Commandes** : `/help`, `/server`, `/ticket`, `/close`, `/bug`, `/suggestion`, `/report`, `/warn`, `/clear`, `/setup`.
- **Logs** : arrivées/départs, modération, suppressions, tickets, démarrage, erreurs.
- **Sécurité** : secrets jamais journalisés (masquage automatique), commandes d'administration protégées par permissions.

## Installation locale

```bash
npm install
cp .env.example .env   # puis renseigner les valeurs
npm run check          # vérification de syntaxe
npm test               # tests unitaires (sans connexion Discord)
npm start
```

## Variables d'environnement

| Variable | Obligatoire | Rôle |
|---|---|---|
| `DISCORD_TOKEN` | oui | Token du bot (ne jamais le publier) |
| `CLIENT_ID` | oui | ID de l'application Discord |
| `GUILD_ID` | oui | ID du serveur Melodix |
| `OWNER_ID` | oui | ID de l'administrateur du bot |
| `AUTO_SETUP` | non | `true` lance le setup au démarrage |
| `ENABLE_MESSAGE_CONTENT` | non | `true` active le contenu des messages supprimés (intent privilégié) |
| `REGISTER_COMMANDS_ON_START` | non | `false` désactive l'enregistrement automatique des commandes |
| `LINK_*` | non | liens affichés dans le salon liens-officiels |

## Connecter le bot à Discord

1. Portail développeur → New Application, puis onglet **Bot** : copier le token (Reset Token).
2. Onglet **Bot** : laisser les intents `Server Members` et `Message Content` selon besoin ; `Message Content` doit être coché si `ENABLE_MESSAGE_CONTENT=true`.
3. Onglet **OAuth2 → URL Generator** : scopes `bot` et `applications.commands`, permission `Administrator` (ou au minimum Gérer les salons, Gérer les rôles, Gérer les messages, Expulser, Bannir, Modérer, Voir le journal d'audit).
4. Ouvrir l'URL générée et inviter le bot sur le serveur Melodix.
5. Renseigner `CLIENT_ID`, `GUILD_ID`, `OWNER_ID` puis lancer `npm start`.

## Déploiement (Antagonix ou hébergeur Node.js)

- Installation : `npm install` (automatique selon l'hébergeur).
- Démarrage : `npm start`.
- Variables : à saisir dans l'interface de l'hébergeur, jamais dans le dépôt.
- Persistance : le dossier `DATA_DIR` (avertissements, hash des commandes) doit être conservé entre redémarrages.
- Mémoire : conçu pour 256 à 512 Mo.

## Structure

```
src/
  index.js            point d'entrée
  constants.js        valeurs stables de l'API Discord
  config/             env, structure du serveur, messages
  commands/           définitions slash et gestionnaires
  events/             interactions, arrivées/départs, messages
  systems/            setup, tickets, logs, salons/rôles
  utils/              logger (masquage des secrets), stockage, cooldown
scripts/              enregistrement des commandes, vérification syntaxe
test/                 tests unitaires
```

## Tests

`npm test` couvre la configuration, le masquage des secrets, les noms de salons, les cooldowns, l'unicité des embeds et des rôles/salons. Les tests nécessitant une connexion réelle (setup sur le serveur, tickets, logs en direct) doivent être exécutés une fois le bot connecté à Discord.
