import 'dotenv/config';
import { Client, Events, GatewayIntentBits, Partials, ActivityType } from 'discord.js';
import { createCommands } from './commands/index.js';
import { registerCommands } from '../scripts/deploy-commands.js';
import { loadEnv } from './config/env.js';
import { registerInteractionEvents } from './events/interactionCreate.js';
import { registerMemberEvents } from './events/guildMemberEvents.js';
import { Color } from './constants.js';
import { runSetup } from './systems/setup.js';
import { sendLog, reportError } from './systems/logs.js';
import { createStore } from './utils/store.js';
import { configureLogger, log } from './utils/logger.js';

let env;
try {
  env = loadEnv();
} catch (e) {
  console.error(`[CONFIG] ${e.message}`);
  process.exit(1);
}
configureLogger({ level: env.logLevel, secrets: [env.token] });

const store = createStore(env.dataDir);
const intents = [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildModeration, GatewayIntentBits.GuildMessages];
if (env.messageContent) intents.push(GatewayIntentBits.MessageContent);

const client = new Client({
  intents,
  partials: [Partials.Message],
  makeCache: (manager) => manager, // cache par défaut, réduit au besoin
  presence: { activities: [{ name: 'Melodix', type: ActivityType.Listening }] },
});

const handlers = createCommands({ env, store });
registerInteractionEvents(client, { env, handlers });
registerMemberEvents(client, { env });

client.on(Events.Error, (e) => reportError(null, e, 'client'));
process.on('unhandledRejection', (e) => reportError(null, e, 'unhandledRejection'));
process.on('uncaughtException', (e) => { log.error('uncaughtException', e); process.exit(1); });

const shutdown = async (signal) => {
  log.info(`Arrêt (${signal})…`);
  await store.flush();
  client.destroy();
  process.exit(0);
};
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

client.once(Events.ClientReady, async (c) => {
  log.info(`Connecté en tant que ${c.user.tag} • ${c.guilds.cache.size} serveur(s)`);
  const guild = await c.guilds.fetch(env.guildId).then((g) => g.fetch()).catch((e) => { log.error('Serveur introuvable :', e.message); return null; });
  if (!guild) return;
  if (env.registerOnStart) {
    const r = await registerCommands(env).catch((e) => { log.error('Enregistrement des commandes :', e.message); return null; });
    if (r && !r.skipped) log.info(`${r.count} commandes enregistrées.`);
  }
  if (env.autoSetup) await runSetup(guild, { env, reason: 'Auto-setup au démarrage' }).catch((e) => reportError(guild, e, 'auto-setup'));
  await sendLog(guild, 'bot', { color: Color.success, title: '🟢 Bot démarré', description: `Version ${process.env.npm_package_version ?? '1.0.0'} • Node ${process.version}` });
});

client.login(env.token).catch((e) => {
  log.error('Connexion Discord impossible :', e.message);
  process.exit(1);
});
