const REQUIRED = ['DISCORD_TOKEN', 'CLIENT_ID', 'GUILD_ID', 'OWNER_ID'];
const IDS = ['CLIENT_ID', 'GUILD_ID', 'OWNER_ID'];
const flag = (v) => String(v ?? '').trim().toLowerCase() === 'true';

/** Valide et fige la configuration. N'affiche jamais les valeurs, uniquement les noms de variables. */
export function loadEnv(src = process.env) {
  const missing = REQUIRED.filter((k) => !src[k] || !String(src[k]).trim());
  if (missing.length) {
    throw new Error(`Variables d'environnement manquantes : ${missing.join(', ')} (voir .env.example)`);
  }
  const invalid = IDS.filter((k) => !/^\d{15,22}$/.test(String(src[k]).trim()));
  if (invalid.length) {
    throw new Error(`Identifiants Discord invalides (numériques attendus) : ${invalid.join(', ')}`);
  }
  const link = (k) => String(src[k] ?? '').trim();
  return Object.freeze({
    token: String(src.DISCORD_TOKEN).trim(),
    clientId: String(src.CLIENT_ID).trim(),
    guildId: String(src.GUILD_ID).trim(),
    ownerId: String(src.OWNER_ID).trim(),
    logLevel: (src.LOG_LEVEL || 'info').trim(),
    dataDir: (src.DATA_DIR || './data').trim(),
    registerOnStart: String(src.REGISTER_COMMANDS_ON_START ?? 'true').trim().toLowerCase() !== 'false',
    autoSetup: flag(src.AUTO_SETUP),
    messageContent: flag(src.ENABLE_MESSAGE_CONTENT),
    links: Object.freeze({
      website: link('LINK_WEBSITE'),
      download: link('LINK_DOWNLOAD'),
      github: link('LINK_GITHUB'),
      support: link('LINK_SUPPORT'),
    }),
  });
}
