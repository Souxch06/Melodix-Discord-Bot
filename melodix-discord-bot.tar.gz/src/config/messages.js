import { ButtonStyle, Color, ComponentType, CustomId } from '../constants.js';

export const refOf = (key) => `ref:${key}`;
export const hasRef = (message, key) =>
  Boolean(message?.embeds?.some((e) => e?.footer?.text?.includes(refOf(key))));

const footer = (key) => ({ text: `Melodix • ${refOf(key)}` });

/** Embeds publiés une seule fois dans leurs salons (repérés par la référence en pied d'embed). */
export function buildMessages(env) {
  const l = env?.links ?? {};
  const linkLines = [
    l.website && `🌐 Site : ${l.website}`,
    l.download && `📥 Télécharger Melodix : ${l.download}`,
    l.github && `💻 GitHub : ${l.github}`,
    l.support && `🆘 Support : ${l.support}`,
  ].filter(Boolean);

  return {
    rules: { embeds: [{
      title: '📜 Règlement du serveur', color: Color.brand, footer: footer('rules'),
      description: [
        '**1. Respect** — Aucune insulte, harcèlement, discrimination ou propos haineux.',
        '**2. Pas de spam** — Pas de flood, pub non autorisée ou mentions abusives.',
        '**3. Contenu adapté** — Aucun contenu NSFW, illégal ou choquant.',
        '**4. Bon salon** — Utilisez les salons aux bons endroits.',
        '**5. Vie privée** — Ne partagez jamais d\'informations personnelles (les vôtres ou celles d\'autrui).',
        '**6. Staff** — Les décisions du staff doivent être respectées. Contestation via un ticket.',
        '**7. Conditions Discord** — Les [CGU de Discord](https://discord.com/terms) s\'appliquent ici.',
      ].join('\n'),
    }] },
    about: { embeds: [{
      title: '🧭 À propos de Melodix', color: Color.brand, footer: footer('about'),
      description: 'Melodix est un projet de musique pour Android. Ce serveur est le point de rencontre de la communauté : annonces, entraide, retours et suggestions.',
      fields: [
        { name: '🎧 Communauté', value: 'Partagez vos découvertes musicales et discutez avec les autres membres.' },
        { name: '🛠️ Projet vivant', value: 'Signalez les bugs avec `/bug` et proposez des idées avec `/suggestion`.' },
      ],
    }] },
    premium: { embeds: [{
      title: '💎 Melodix Premium', color: Color.warn, footer: footer('premium'),
      description: 'Le rôle **💎 Melodix Premium** est réservé aux membres Premium. Les informations sur l\'offre sont communiquées dans le salon des annonces.',
      fields: [{ name: 'Une question ?', value: 'Ouvrez un ticket depuis le salon dédié.' }],
    }] },
    faq: { embeds: [{
      title: '❓ Foire aux questions', color: Color.info, footer: footer('faq'),
      fields: [
        { name: 'Comment obtenir de l\'aide ?', value: 'Ouvrez un ticket via le bouton du salon 🎫│ouvrir-un-ticket ou utilisez `/ticket`.' },
        { name: 'Comment signaler un bug ?', value: 'Utilisez `/bug` en décrivant le problème et les étapes pour le reproduire.' },
        { name: 'Comment proposer une idée ?', value: 'Utilisez `/suggestion`, la communauté pourra voter.' },
        { name: 'Comment signaler un membre ?', value: 'Utilisez `/report` : seul le staff voit le signalement.' },
      ],
    }] },
    guide: { embeds: [{
      title: '📖 Guide du serveur', color: Color.brand, footer: footer('guide'),
      description: 'Bienvenue ! Voici comment tirer le meilleur du serveur.',
      fields: [
        { name: '1️⃣ Lisez le règlement', value: 'Salon 📜│règlement.' },
        { name: '2️⃣ Présentez-vous', value: 'Dites bonjour dans 💬│général et partagez vos goûts musicaux.' },
        { name: '3️⃣ Utilisez les commandes', value: 'Tapez `/help` dans 🤖│commandes-bot pour voir toutes les commandes.' },
        { name: '4️⃣ Besoin du staff ?', value: 'Ouvrez un ticket, nous répondons dès que possible.' },
      ],
    }] },
    links: { embeds: [{
      title: '🔗 Liens officiels', color: Color.info, footer: footer('links'),
      description: linkLines.length ? linkLines.join('\n') : 'Les liens officiels seront ajoutés prochainement.',
    }] },
    tickets: {
      embeds: [{
        title: '🎫 Support — Ouvrir un ticket', color: Color.success, footer: footer('tickets'),
        description: 'Besoin d\'aide, d\'un renseignement ou d\'un échange privé avec le staff ?\nCliquez sur le bouton ci-dessous : un salon privé sera créé pour vous.\n\n*Un seul ticket ouvert à la fois par membre.*',
      }],
      components: [{ type: ComponentType.ActionRow, components: [
        { type: ComponentType.Button, style: ButtonStyle.Success, label: 'Ouvrir un ticket', emoji: { name: '🎫' }, custom_id: CustomId.ticketOpen },
      ] }],
    },
  };
}
