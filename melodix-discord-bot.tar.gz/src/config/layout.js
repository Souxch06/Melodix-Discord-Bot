// Structure du serveur Melodix. Modifier ce fichier suffit pour adapter rôles, catégories et salons.
// visibility : public | readonly | staff | dev | logs
import { ChannelType } from '../constants.js';

const T = ChannelType.Text;
const V = ChannelType.Voice;

export const ROLES = [
  { key: 'founder', name: '👑 Fondateur', color: 0xf1c40f, hoist: true, staff: true, permissions: ['Administrator'] },
  { key: 'coFounder', name: '🧠 Co-Fondateur', color: 0xe67e22, hoist: true, staff: true, permissions: ['Administrator'] },
  { key: 'admin', name: '⚙️ Administrateur', color: 0xe74c3c, hoist: true, staff: true,
    permissions: ['ManageGuild', 'ManageChannels', 'ManageRoles', 'ManageMessages', 'KickMembers', 'BanMembers', 'ModerateMembers', 'ViewAuditLog'] },
  { key: 'leadDev', name: '💻 Lead Developer', color: 0x9b59b6, hoist: true, staff: true, permissions: ['ManageWebhooks', 'ManageThreads'] },
  { key: 'mod', name: '🔨 Modérateur', color: 0x3498db, hoist: true, staff: true,
    permissions: ['ManageMessages', 'KickMembers', 'ModerateMembers', 'ViewAuditLog', 'ManageThreads'] },
  { key: 'helper', name: '🛡️ Helper', color: 0x2ecc71, hoist: true, staff: true, permissions: ['ManageMessages'] },
  { key: 'bots', name: '🤖 Bots', color: 0x95a5a6, hoist: true, permissions: [] },
  { key: 'premium', name: '💎 Melodix Premium', color: 0xe91e63, hoist: true, permissions: [] },
  { key: 'member', name: '🎧 Melodix Member', color: 0x1abc9c, permissions: [] },
  { key: 'newcomer', name: '🆕 Nouveau', color: 0xbdc3c7, permissions: [] },
  { key: 'musicLover', name: '🎵 Music Lover', color: 0xff6b9d, permissions: [] },
  { key: 'artist', name: '🎤 Artiste', color: 0xaf7ac5, permissions: [] },
  { key: 'dj', name: '🎧 DJ', color: 0x5dade2, permissions: [] },
  { key: 'developer', name: '💻 Développeur', color: 0x58d68d, dev: true, permissions: [] },
  { key: 'gamer', name: '🎮 Gamer', color: 0xeb984e, permissions: [] },
  { key: 'mobile', name: '📱 Mobile', color: 0x85c1e9, permissions: [] },
  { key: 'pc', name: '🖥️ PC', color: 0x7f8c8d, permissions: [] },
];

export const STAFF_ROLE_KEYS = ROLES.filter((r) => r.staff).map((r) => r.key);
export const DEV_ROLE_KEYS = [...STAFF_ROLE_KEYS, ...ROLES.filter((r) => r.dev).map((r) => r.key)];

export const CATEGORIES = [
  { key: 'info', name: '📌 INFORMATIONS', visibility: 'public', channels: [
    { key: 'rules', name: '📜│règlement', type: T, visibility: 'readonly', post: 'rules' },
    { key: 'announcements', name: '📢│annonces', type: T, visibility: 'readonly' },
    { key: 'welcome', name: '👋│bienvenue', type: T, visibility: 'readonly' },
    { key: 'about', name: '🧭│à-propos', type: T, visibility: 'readonly', post: 'about' },
    { key: 'faq', name: '❓│faq', type: T, visibility: 'readonly', post: 'faq' },
    { key: 'links', name: '🔗│liens-officiels', type: T, visibility: 'readonly', post: 'links' },
  ] },
  { key: 'melodix', name: '🎧 MELODIX', visibility: 'public', channels: [
    { key: 'guide', name: '📖│guide', type: T, visibility: 'readonly', post: 'guide' },
    { key: 'premiumInfo', name: '💎│premium', type: T, visibility: 'readonly', post: 'premium' },
    { key: 'news', name: '🆕│nouveautés', type: T, visibility: 'readonly' },
  ] },
  { key: 'community', name: '💬 COMMUNAUTÉ', visibility: 'public', channels: [
    { key: 'general', name: '💬│général', type: T },
    { key: 'media', name: '🖼️│médias', type: T },
    { key: 'musicShare', name: '🎵│partage-musique', type: T },
    { key: 'botCommands', name: '🤖│commandes-bot', type: T },
  ] },
  { key: 'melodixCommunity', name: '💡 COMMUNAUTÉ MELODIX', visibility: 'public', channels: [
    { key: 'suggestions', name: '💡│suggestions', type: T, visibility: 'readonly' },
    { key: 'bugs', name: '🐞│bugs', type: T, visibility: 'readonly' },
    { key: 'feedback', name: '📝│retours', type: T },
  ] },
  { key: 'supportHelp', name: '🆘 SUPPORT', visibility: 'public', channels: [
    { key: 'help', name: '🆘│aide', type: T },
  ] },
  { key: 'supportTickets', name: '🎫 SUPPORT', visibility: 'public', channels: [
    { key: 'ticketPanel', name: '🎫│ouvrir-un-ticket', type: T, visibility: 'readonly', post: 'tickets' },
  ] },
  { key: 'voice', name: '🔊 VOCAL', visibility: 'public', channels: [
    { key: 'vGeneral', name: '🔊 Général', type: V },
    { key: 'vMusic', name: '🎵 Musique', type: V },
    { key: 'vChill', name: '🎧 Chill', type: V },
    { key: 'vGaming', name: '🎮 Gaming', type: V },
    { key: 'vAfk', name: '😴 AFK', type: V },
  ] },
  { key: 'staff', name: '🛡️ STAFF', visibility: 'staff', channels: [
    { key: 'staffChat', name: '💬│staff-chat', type: T },
    { key: 'reports', name: '🚨│reports', type: T },
    { key: 'staffCommands', name: '📋│staff-commandes', type: T },
  ] },
  { key: 'dev', name: '💻 DÉVELOPPEMENT', visibility: 'dev', channels: [
    { key: 'devChat', name: '💻│dev-chat', type: T },
    { key: 'devTests', name: '🧪│tests-bot', type: T },
    { key: 'devResources', name: '🔧│dev-ressources', type: T },
  ] },
  { key: 'logs', name: '📜 LOGS', visibility: 'logs', channels: [
    { key: 'logMembers', name: '📥│logs-membres', type: T },
    { key: 'logModeration', name: '🔨│logs-moderation', type: T },
    { key: 'logMessages', name: '🗑️│logs-messages', type: T },
    { key: 'logTickets', name: '🎫│logs-tickets', type: T },
    { key: 'logBot', name: '🤖│logs-bot', type: T },
    { key: 'logErrors', name: '🚨│logs-erreurs', type: T },
  ] },
];

export const ALL_CHANNELS = CATEGORIES.flatMap((c) =>
  c.channels.map((ch) => ({ ...ch, categoryKey: c.key, visibility: ch.visibility ?? c.visibility })));
export const getChannelDef = (key) => ALL_CHANNELS.find((c) => c.key === key);
export const getCategoryDef = (key) => CATEGORIES.find((c) => c.key === key);
export const getRoleDef = (key) => ROLES.find((r) => r.key === key);

// Alias des salons de logs → clé de salon
export const LOG_CHANNELS = Object.freeze({
  members: 'logMembers', moderation: 'logModeration', messages: 'logMessages',
  tickets: 'logTickets', bot: 'logBot', errors: 'logErrors',
});
