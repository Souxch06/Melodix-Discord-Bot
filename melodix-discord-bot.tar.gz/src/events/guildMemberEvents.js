import { Color, Events } from '../constants.js';
import { findRole } from '../systems/channels.js';
import { sendLog } from '../systems/logs.js';
import { safe } from '../utils/safe.js';
import { log } from '../utils/logger.js';

export function registerMemberEvents(client, { env }) {
  client.on(Events.GuildMemberAdd, async (m) => {
    if (m.user.bot) return;
    const newcomer = findRole(m.guild, 'newcomer');
    if (newcomer) await safe(() => m.roles.add(newcomer, 'Nouveau membre'));
    await sendLog(m.guild, 'members', { color: Color.success, title: '📥 Arrivée', description: `${m.user} (${m.user.tag ?? m.user.username}) a rejoint le serveur.`,
      fields: [{ name: 'Compte créé', value: `<t:${Math.floor(m.user.createdTimestamp / 1000)}:R>` }] });
  });

  client.on(Events.GuildMemberRemove, async (m) => {
    await sendLog(m.guild, 'members', { color: Color.danger, title: '📤 Départ', description: `${m.user?.tag ?? m.id} a quitté le serveur.` });
  });

  client.on(Events.MessageDelete, async (msg) => {
    if (!msg.guild || msg.author?.bot) return;
    const content = msg.content ? msg.content.slice(0, 900) : '*Contenu non disponible (intent "Message Content" désactivé ou message non mis en cache)*';
    await sendLog(msg.guild, 'messages', { color: Color.danger, title: '🗑️ Message supprimé', fields: [
      { name: 'Auteur', value: msg.author ? `${msg.author} (${msg.author.id})` : 'Inconnu', inline: true },
      { name: 'Salon', value: `${msg.channel}`, inline: true },
      { name: 'Contenu', value: content },
    ] });
  });

  client.on(Events.GuildBanAdd, (ban) => sendLog(ban.guild, 'moderation', { color: Color.danger, title: '🔨 Bannissement', description: `${ban.user.tag ?? ban.user.id} a été banni.` }));
  client.on(Events.GuildBanRemove, (ban) => sendLog(ban.guild, 'moderation', { color: Color.success, title: '♻️ Débannissement', description: `${ban.user.tag ?? ban.user.id} a été débanni.` }));
  log.debug('Événements membres enregistrés');
}
