import { Events } from 'discord.js';
import { dispatchCommand } from '../commands/index.js';
import { closeTicket, openTicket, canCloseTicket } from '../systems/tickets.js';
import { CustomId } from '../constants.js';
import { ephemeral, respond } from '../utils/safe.js';
import { log } from '../utils/logger.js';

export function registerInteractionEvents(client, { env, handlers }) {
  client.on(Events.InteractionCreate, async (i) => {
    try {
      if (i.isChatInputCommand()) return void await dispatchCommand(i, handlers);
      if (i.isButton()) {
        if (i.customId === CustomId.ticketOpen) {
          await i.deferReply({ flags: 64 });
          const { channel, created, error } = await openTicket(i.guild, i.member, 'Bouton');
          if (error) return void respond(i, ephemeral('❌ Impossible de créer le ticket.'));
          return void respond(i, ephemeral(created ? `🎫 Ticket créé : ${channel}` : `ℹ️ Ticket déjà ouvert : ${channel}`));
        }
        if (i.customId === CustomId.ticketClose) {
          if (!canCloseTicket(i.channel, i.member, env)) {
            return void respond(i, ephemeral('⛔ Seul le propriétaire du ticket ou le staff peut le fermer.'));
          }
          await closeTicket(i.channel, i.user);
          return void respond(i, ephemeral('🔒 Fermeture en cours.'));
        }
      }
    } catch (e) {
      log.error('interactionCreate :', e);
    }
  });
}
