import { ChannelType, Color, OverwriteType } from '../constants.js';
import { getCategoryDef } from '../config/layout.js';
import { log } from '../utils/logger.js';
import { safe } from '../utils/safe.js';
import { ticketSlug } from '../utils/text.js';
import { findCategory, findRole, isStaff, list, staffRoles } from './channels.js';
import { sendLog } from './logs.js';

export const TICKET_TOPIC_PREFIX = 'ticket-owner:';

/** Retourne le salon de ticket ouvert par ce membre, s'il existe. */
export function findOpenTicket(guild, userId) {
  return list(guild.channels.cache).find((c) =>
    c.type === ChannelType.GuildText && c.topic?.startsWith(TICKET_TOPIC_PREFIX + userId)) ?? null;
}

export async function openTicket(guild, member, reason = 'Ticket') {
  const existing = findOpenTicket(guild, member.id);
  if (existing) return { channel: existing, created: false };

  const cat = findCategory(guild, 'supportHelp') ?? findCategory(guild, 'supportTickets');
  const everyone = guild.roles.everyone.id;
  const overwrites = [
    { id: everyone, type: OverwriteType.Role, deny: ['ViewChannel'] },
    { id: member.id, type: OverwriteType.Member, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'AttachFiles', 'EmbedLinks'] },
    { id: guild.client.user.id, type: OverwriteType.Member, allow: ['ViewChannel', 'SendMessages', 'ManageChannels', 'ReadMessageHistory'] },
    ...staffRoles(guild).map((r) => ({ id: r.id, type: OverwriteType.Role, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'] })),
  ];
  const channel = await safe(() => guild.channels.create({
    name: `ticket-${ticketSlug(member.user.username)}`,
    type: ChannelType.GuildText,
    parent: cat?.id,
    topic: `${TICKET_TOPIC_PREFIX}${member.id} • ${reason}`.slice(0, 1024),
    permissionOverwrites: overwrites,
    reason: `Ticket de ${member.user.tag ?? member.user.username}`,
  }));
  if (!channel) return { channel: null, created: false, error: 'create' };

  await safe(() => channel.send({
    content: `${member}`,
    embeds: [{
      color: Color.success, title: '🎫 Ticket ouvert',
      description: 'Décrivez votre demande. Le staff vous répondra ici dès que possible.\nUtilisez le bouton ci-dessous ou `/close` pour fermer le ticket.',
      timestamp: new Date().toISOString(),
    }],
    components: [{ type: 1, components: [{ type: 2, style: 4, label: 'Fermer le ticket', emoji: { name: '🔒' }, custom_id: 'ticket:close' }] }],
    allowedMentions: { users: [member.id], roles: [] },
  }));
  await sendLog(guild, 'tickets', { color: Color.success, title: '🎫 Ticket créé', description: `${member} a ouvert ${channel}.` });
  log.info(`Ticket créé (#${channel.id}) pour l'utilisateur ${member.id}`);
  return { channel, created: true };
}

export async function closeTicket(channel, closer) {
  if (!channel?.topic?.startsWith(TICKET_TOPIC_PREFIX)) return { ok: false, reason: 'not-ticket' };
  const ownerId = channel.topic.slice(TICKET_TOPIC_PREFIX.length).split(' ')[0];
  const guild = channel.guild;
  await sendLog(guild, 'tickets', { color: Color.danger, title: '🔒 Ticket fermé', description: `Salon ${channel.name} fermé par ${closer} (propriétaire : <@${ownerId}>).` });
  await safe(() => channel.send({ embeds: [{ color: Color.danger, description: `🔒 Ticket fermé par ${closer}. Suppression dans 5 secondes.` }] }));
  setTimeout(() => safe(() => channel.delete(`Ticket fermé par ${closer.tag ?? closer.id}`)), 5000).unref?.();
  return { ok: true, ownerId };
}

export const canCloseTicket = (channel, member, env) => {
  if (!channel?.topic?.startsWith(TICKET_TOPIC_PREFIX)) return false;
  const owner = channel.topic.slice(TICKET_TOPIC_PREFIX.length).split(' ')[0];
  return member.id === owner || isStaff(member, env);
};
