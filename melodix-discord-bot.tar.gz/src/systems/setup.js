import { ChannelType, OverwriteType } from '../constants.js';
import { CATEGORIES, ROLES, getRoleDef } from '../config/layout.js';
import { buildMessages, hasRef } from '../config/messages.js';
import { log } from '../utils/logger.js';
import { safe } from '../utils/safe.js';
import { nameKey } from '../utils/text.js';
import { findCategory, findChannel, findRole, list, staffRoles } from './channels.js';

const pause = (ms) => new Promise((r) => setTimeout(r, ms));

/** Permissions d'un salon selon sa visibilité. Renvoie [] pour un salon public. */
function overwritesFor(guild, visibility, roles) {
  const everyone = guild.roles.everyone.id;
  const staff = staffRoles(guild).map((r) => r.id);
  const dev = [...staff, ...(roles.developer ? [roles.developer.id] : [])];
  const logs = [...staff];
  const deny = (id) => ({ id, type: OverwriteType.Role, deny: ['ViewChannel'] });
  const allow = (id, extra = []) => ({ id, type: OverwriteType.Role, allow: ['ViewChannel', ...extra] });
  const readOnly = (id) => ({ id, type: OverwriteType.Role, allow: ['ViewChannel', 'ReadMessageHistory'], deny: ['SendMessages', 'AddReactions', 'CreatePublicThreads'] });

  switch (visibility) {
    case 'readonly': return [readOnly(everyone)];
    case 'staff': return [deny(everyone), ...staff.map((id) => allow(id, ['SendMessages']))];
    case 'dev': return [deny(everyone), ...dev.map((id) => allow(id, ['SendMessages']))];
    case 'logs': return [deny(everyone), ...logs.map((id) => allow(id))];
    default: return [];
  }
}

/** Crée rôles, catégories, salons et messages. Idempotent : chaque élément est recherché avant création. */
export async function runSetup(guild, { env, reason = 'Setup Melodix' } = {}) {
  const report = { roles: 0, categories: 0, channels: 0, messages: 0, skipped: 0, errors: [] };
  await guild.roles.fetch().catch(() => {});
  await guild.channels.fetch().catch(() => {});

  // 1. Rôles
  for (const def of ROLES) {
    if (findRole(guild, def.key)) { report.skipped++; continue; }
    const role = await safe(() => guild.roles.create({
      name: def.name, color: def.color, hoist: Boolean(def.hoist), mentionable: false,
      permissions: [], reason,
    }));
    if (role) report.roles++; else report.errors.push(`rôle ${def.name}`);
    await pause(250);
  }
  const roleMap = Object.fromEntries(ROLES.map((r) => [r.key, findRole(guild, r.key)]));

  // 2. Catégories + salons
  for (const cat of CATEGORIES) {
    let category = findCategory(guild, cat.key);
    if (!category) {
      const visibility = cat.visibility;
      category = await safe(() => guild.channels.create({
        name: cat.name, type: ChannelType.Category, reason,
        permissionOverwrites: overwritesFor(guild, visibility, roleMap),
      }));
      if (category) report.categories++; else { report.errors.push(`catégorie ${cat.name}`); continue; }
      await pause(250);
    } else report.skipped++;

    for (const ch of cat.channels) {
      const visibility = ch.visibility ?? cat.visibility;
      const existing = findChannel(guild, ch.key);
      if (existing) {
        report.skipped++;
        if (existing.parentId !== category.id) {
          await safe(() => existing.setParent(category.id, { lockPermissions: false, reason }));
        }
        continue;
      }
      const created = await safe(() => guild.channels.create({
        name: ch.name, type: ch.type, parent: category.id, reason,
        permissionOverwrites: overwritesFor(guild, visibility, roleMap),
      }));
      if (created) report.channels++; else report.errors.push(`salon ${ch.name}`);
      await pause(250);
    }
  }

  // 3. Messages automatiques : publiés une seule fois, jamais republiés au redémarrage.
  const messages = buildMessages(env);
  const postMap = { rules: 'rules', about: 'about', faq: 'faq', guide: 'guide', premium: 'premium', links: 'links', tickets: 'tickets' };
  for (const ch of list(guild.channels.cache)) {
    const key = Object.keys(postMap).find((k) => {
      const def = CATEGORIES.flatMap((c) => c.channels).find((x) => x.post === k);
      return def && nameKey(def.name) === nameKey(ch.name);
    });
    if (!key || ch.type !== ChannelType.GuildText) continue;
    const payload = messages[postMap[key]];
    if (!payload) continue;
    const ref = postMap[key];
    const recent = await safe(() => ch.messages.fetch({ limit: 25 }), null);
    if (recent && list(recent.values()).some((m) => m.author?.id === guild.client.user.id && hasRef(m, ref))) {
      report.skipped++;
      continue;
    }
    const sent = await safe(() => ch.send({ ...payload, allowedMentions: { parse: [] } }));
    if (sent) { report.messages++; await sent.pin?.().catch(() => {}); }
    await pause(400);
  }

  log.info(`Setup terminé : ${report.roles} rôles, ${report.categories} catégories, ${report.channels} salons, ${report.messages} messages, ${report.skipped} éléments existants, ${report.errors.length} erreurs.`);
  return report;
}
