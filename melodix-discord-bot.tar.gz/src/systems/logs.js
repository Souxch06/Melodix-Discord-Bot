import { Color } from '../constants.js';
import { LOG_CHANNELS } from '../config/layout.js';
import { log } from '../utils/logger.js';
import { safe } from '../utils/safe.js';
import { truncate } from '../utils/text.js';
import { findChannel } from './channels.js';

/** Envoie un embed dans un salon de logs (members|moderation|messages|tickets|bot|errors). */
export async function sendLog(guild, type, embed, extra = {}) {
  const channel = guild ? findChannel(guild, LOG_CHANNELS[type]) : null;
  if (!channel) return false;
  const ok = await safe(async () => {
    await channel.send({ embeds: [{ color: Color.neutral, timestamp: new Date().toISOString(), ...embed }], allowedMentions: { parse: [] }, ...extra });
    return true;
  }, false);
  return ok;
}

let lastErrorAt = 0;
/** Journalise une erreur dans les logs et dans 🚨│logs-erreurs (au plus une fois toutes les 10 s). */
export async function reportError(guild, error, context = '') {
  log.error(context, error);
  const now = Date.now();
  if (now - lastErrorAt < 10_000) return false;
  lastErrorAt = now;
  return sendLog(guild, 'errors', {
    color: Color.danger,
    title: '🚨 Erreur',
    description: `\`\`\`${truncate(String(error?.stack ?? error?.message ?? error).replace(/```/g, "'''"), 1500)}\`\`\``,
    fields: context ? [{ name: 'Contexte', value: truncate(context, 200) }] : [],
  });
}
export const _resetErrorGate = () => { lastErrorAt = 0; };
