import { ChannelType } from '../constants.js';
import { getCategoryDef, getChannelDef, getRoleDef, STAFF_ROLE_KEYS } from '../config/layout.js';
import { coreName, nameKey } from '../utils/text.js';

export const list = (c) => Array.from(c?.values?.() ?? c ?? []);

export function findChannel(guild, key) {
  const def = getChannelDef(key);
  if (!def) return null;
  const core = coreName(def.name);
  return list(guild.channels.cache).find((c) => c.type === def.type && coreName(c.name) === core) ?? null;
}

export function findCategory(guild, key) {
  const def = getCategoryDef(key);
  if (!def) return null;
  return list(guild.channels.cache).find((c) => c.type === ChannelType.Category && nameKey(c.name) === nameKey(def.name)) ?? null;
}

export function findRole(guild, key) {
  const def = getRoleDef(key);
  if (!def) return null;
  return list(guild.roles.cache).find((r) => nameKey(r.name) === nameKey(def.name)) ?? null;
}

export const staffRoles = (guild) => STAFF_ROLE_KEYS.map((k) => findRole(guild, k)).filter(Boolean);

/** Staff = propriétaire configuré, permission Administrateur, ou l'un des rôles staff. */
export function isStaff(member, env) {
  if (!member) return false;
  if (env && member.id === env.ownerId) return true;
  if (member.permissions?.has?.('Administrator')) return true;
  const staffNames = new Set(STAFF_ROLE_KEYS.map((k) => nameKey(getRoleDef(k).name)));
  return list(member.roles?.cache).some((r) => staffNames.has(nameKey(r.name)));
}

export function isLogChannel(channel) {
  const cat = getCategoryDef('logs');
  return Boolean(cat) && channel?.parent != null && nameKey(channel.parent.name) === nameKey(cat.name);
}
