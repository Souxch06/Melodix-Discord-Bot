// Valeurs numériques stables de l'API Discord (évite d'importer discord.js dans la logique métier).
export const ChannelType = Object.freeze({ Text: 0, Voice: 2, Category: 4 });
export const OverwriteType = Object.freeze({ Role: 0, Member: 1 });
export const ButtonStyle = Object.freeze({ Primary: 1, Secondary: 2, Success: 3, Danger: 4 });
export const ComponentType = Object.freeze({ ActionRow: 1, Button: 2 });
export const OptionType = Object.freeze({ String: 3, Integer: 4, Boolean: 5, User: 6 });
export const EPHEMERAL = 64;

export const Color = Object.freeze({
  brand: 0x7c5cff,
  success: 0x2ecc71,
  warn: 0xf1c40f,
  danger: 0xe74c3c,
  info: 0x3498db,
  neutral: 0x95a5a6,
});

// default_member_permissions (bitfields sous forme de chaînes)
export const PermBits = Object.freeze({
  Administrator: '8',
  ManageMessages: '8192',
  ModerateMembers: '1099511627776',
});

export const CustomId = Object.freeze({ ticketOpen: 'ticket:open', ticketClose: 'ticket:close' });
