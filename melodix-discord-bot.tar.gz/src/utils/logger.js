const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const TOKEN_RE = /[\w-]{23,28}\.[\w-]{6,7}\.[\w-]{27,}/g;
let threshold = LEVELS.info;
const secrets = new Set();

export function configureLogger({ level = 'info', secrets: list = [] } = {}) {
  threshold = LEVELS[level] ?? LEVELS.info;
  for (const s of list) if (s && String(s).length >= 8) secrets.add(String(s));
}

/** Masque les secrets connus et tout motif ressemblant à un token Discord. */
export function redact(value) {
  let out = String(value);
  for (const s of secrets) out = out.split(s).join('[REDACTED]');
  return out.replace(TOKEN_RE, '[REDACTED]');
}

function render(arg) {
  if (arg instanceof Error) return arg.stack ?? arg.message;
  if (typeof arg === 'object' && arg !== null) {
    try { return JSON.stringify(arg); } catch { return String(arg); }
  }
  return String(arg);
}

function emit(level, args) {
  if (LEVELS[level] < threshold) return;
  const line = `${new Date().toISOString()} [${level.toUpperCase()}] ${redact(args.map(render).join(' '))}`;
  (level === 'error' || level === 'warn' ? console.error : console.log)(line);
}

export const log = {
  debug: (...a) => emit('debug', a),
  info: (...a) => emit('info', a),
  warn: (...a) => emit('warn', a),
  error: (...a) => emit('error', a),
};
