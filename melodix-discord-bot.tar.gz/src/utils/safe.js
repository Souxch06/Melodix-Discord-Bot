import { EPHEMERAL } from '../constants.js';
import { log } from './logger.js';

// 10062 interaction inconnue/expirée, 40060 déjà acquittée, 10008 message inconnu, 10003 salon inconnu
const IGNORABLE = new Set([10062, 40060, 10008, 10003]);
export const isIgnorable = (e) => IGNORABLE.has(e?.code);

/** Exécute fn sans jamais lever : les erreurs Discord attendues sont ignorées, les autres journalisées. */
export async function safe(fn, fallback = null) {
  try {
    return await fn();
  } catch (e) {
    if (!isIgnorable(e)) log.warn('Opération Discord échouée :', e?.code ?? '', e?.message ?? e);
    return fallback;
  }
}

export const ephemeral = (content) => ({ content, flags: EPHEMERAL });

/** Répond à une interaction quel que soit son état (déjà différée / répondue / expirée). */
export async function respond(interaction, payload) {
  return safe(async () => {
    if (interaction.deferred && !interaction.replied) {
      const { flags, ...edit } = payload; // les flags ne sont pas modifiables via editReply
      return interaction.editReply(edit);
    }
    if (interaction.replied || interaction.deferred) return interaction.followUp(payload);
    return interaction.reply(payload);
  });
}
