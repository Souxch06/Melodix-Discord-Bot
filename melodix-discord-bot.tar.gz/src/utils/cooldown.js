/** Anti-spam léger en mémoire. take(key) renvoie 0 si autorisé, sinon les ms restantes. */
export function createCooldown(ms, now = Date.now) {
  const hits = new Map();
  return {
    take(key) {
      const t = now();
      const last = hits.get(key);
      if (last !== undefined && t - last < ms) return ms - (t - last);
      hits.set(key, t);
      if (hits.size > 500) for (const [k, v] of hits) if (t - v >= ms) hits.delete(k);
      return 0;
    },
  };
}
