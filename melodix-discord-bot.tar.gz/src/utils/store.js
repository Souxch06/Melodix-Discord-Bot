import { mkdirSync, readFileSync } from 'node:fs';
import { rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { log } from './logger.js';

/** Mini stockage JSON (avertissements). Écriture atomique et groupée pour économiser les I/O. */
export function createStore(dir) {
  mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'warns.json');
  let data = {};
  try {
    data = JSON.parse(readFileSync(file, 'utf8'));
  } catch (e) {
    if (e.code !== 'ENOENT') log.warn('warns.json illisible, démarrage à vide :', e.message);
  }
  let timer = null;
  let writing = Promise.resolve();

  const flush = () => {
    if (timer) { clearTimeout(timer); timer = null; }
    writing = writing.then(async () => {
      const tmp = `${file}.tmp`;
      await writeFile(tmp, JSON.stringify(data));
      await rename(tmp, file);
    }).catch((e) => log.error('Écriture du stockage impossible :', e.message));
    return writing;
  };

  return {
    addWarn(userId, entry) {
      (data[userId] ??= []).push(entry);
      if (!timer) { timer = setTimeout(flush, 500); timer.unref?.(); }
      return data[userId].length;
    },
    getWarns: (userId) => data[userId] ?? [],
    flush,
  };
}
