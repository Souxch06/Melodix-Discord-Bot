// Les sélecteurs de variation (U+FE0F) et ZWJ peuvent être retirés par Discord : on les ignore pour comparer.
export const stripVS = (s) => String(s).replace(/[\uFE0F\u200D]/g, '');

/** Clé de comparaison complète (catégories, rôles). */
export function nameKey(name) {
  return stripVS(name).toLowerCase().replace(/\s+/g, ' ').trim();
}

/** Nom "cœur" d'un salon : sans emoji de tête ni préfixe "│", espaces → tirets. */
export function coreName(name) {
  let s = stripVS(name).toLowerCase().trim();
  const i = Math.max(s.lastIndexOf('│'), s.lastIndexOf('|'));
  if (i >= 0) s = s.slice(i + 1);
  return s.replace(/^[^\p{L}\p{N}]+/u, '').trim().replace(/\s+/g, '-');
}

export const truncate = (s, n) => {
  const str = String(s ?? '');
  return str.length > n ? `${str.slice(0, n - 1)}…` : str;
};

export function ticketSlug(username) {
  const s = String(username)
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  return s || 'membre';
}
