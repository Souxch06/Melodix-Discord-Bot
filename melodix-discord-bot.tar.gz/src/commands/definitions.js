import { OptionType, PermBits } from '../constants.js';

const reasonOpt = (desc = 'Raison') => ({ type: OptionType.String, name: 'raison', description: desc, required: false, max_length: 500 });

/** Définitions JSON des commandes slash (enregistrées via l'API Discord). */
export const commandDefinitions = [
  { name: 'help', description: 'Affiche la liste des commandes du bot.' },
  { name: 'server', description: 'Affiche les informations du serveur Melodix.' },
  { name: 'ticket', description: 'Ouvre un ticket de support privé.', options: [reasonOpt('Sujet de votre demande')] },
  { name: 'bug', description: 'Signale un bug sur Melodix.', options: [
    { type: OptionType.String, name: 'description', description: 'Décrivez le problème', required: true, max_length: 1000 },
    { type: OptionType.String, name: 'etapes', description: 'Étapes pour reproduire', required: false, max_length: 1000 },
  ] },
  { name: 'suggestion', description: 'Propose une idée pour Melodix.', options: [
    { type: OptionType.String, name: 'idee', description: 'Votre suggestion', required: true, max_length: 1000 },
  ] },
  { name: 'report', description: 'Signale un membre au staff (visible par le staff seulement).', options: [
    { type: OptionType.User, name: 'membre', description: 'Membre concerné', required: true },
    { type: OptionType.String, name: 'motif', description: 'Motif du signalement', required: true, max_length: 500 },
  ] },
  { name: 'close', description: 'Ferme le ticket actuel.' },
  { name: 'warn', description: 'Avertit un membre (staff).', default_member_permissions: PermBits.ModerateMembers, options: [
    { type: OptionType.User, name: 'membre', description: 'Membre à avertir', required: true },
    reasonOpt('Motif de l\'avertissement'),
  ] },
  { name: 'clear', description: 'Supprime des messages récents (staff).', default_member_permissions: PermBits.ManageMessages, options: [
    { type: OptionType.Integer, name: 'nombre', description: 'Entre 1 et 100', required: true, min_value: 1, max_value: 100 },
  ] },
  { name: 'setup', description: 'Configure le serveur Melodix (idempotent).', default_member_permissions: PermBits.Administrator },
];
