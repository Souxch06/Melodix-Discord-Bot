import { Color, EPHEMERAL } from '../constants.js';
import { canCloseTicket, closeTicket, openTicket } from '../systems/tickets.js';
import { isStaff } from '../systems/channels.js';
import { sendLog } from '../systems/logs.js';
import { runSetup } from '../systems/setup.js';
import { createCooldown } from '../utils/cooldown.js';
import { log } from '../utils/logger.js';
import { ephemeral, respond, safe } from '../utils/safe.js';
import { truncate } from '../utils/text.js';

const cooldown = createCooldown(5_000);
const ALL_NAMES = ['help', 'server', 'ticket', 'bug', 'suggestion', 'report', 'close', 'warn', 'clear', 'setup'];

const staffOnly = (i, env) => {
  if (isStaff(i.member, env)) return true;
  respond(i, ephemeral('⛔ Cette commande est réservée au staff.'));
  return false;
};

/** Crée le gestionnaire des commandes, lié à la configuration et au stockage. */
export function createCommands({ env, store }) {
  return {
    async help(i) {
      return respond(i, ephemeral(
        '**Commandes Melodix**\n' +
        '`/help` — affiche cette aide\n' +
        '`/server` — informations du serveur\n' +
        '`/ticket` — ouvre un ticket privé\n' +
        '`/close` — ferme le ticket actuel\n' +
        '`/bug` — signale un bug\n' +
        '`/suggestion` — propose une idée\n' +
        '`/report` — signale un membre au staff\n' +
        '*Staff :* `/warn`, `/clear`, `/setup`',
      ));
    },

    async server(i) {
      const g = i.guild;
      return respond(i, { embeds: [{
        color: Color.brand, title: `🎧 ${g.name}`,
        thumbnail: g.iconURL() ? { url: g.iconURL() } : undefined,
        fields: [
          { name: 'Membres', value: String(g.memberCount ?? 'Inconnu'), inline: true },
          { name: 'Salons', value: String(g.channels.cache.size), inline: true },
          { name: 'Rôles', value: String(g.roles.cache.size), inline: true },
          { name: 'Créé le', value: `<t:${Math.floor(g.createdTimestamp / 1000)}:D>`, inline: true },
        ],
      }] });
    },

    async ticket(i) {
      const reason = i.options.getString('raison') ?? 'Ticket via commande';
      await i.deferReply({ flags: EPHEMERAL });
      const { channel, created, error } = await openTicket(i.guild, i.member, reason);
      if (error) return respond(i, ephemeral('❌ Impossible de créer le ticket (permissions du bot ?).'));
      return respond(i, ephemeral(created ? `🎫 Ticket créé : ${channel}` : `ℹ️ Vous avez déjà un ticket ouvert : ${channel}`));
    },

    async close(i) {
      if (!canCloseTicket(i.channel, i.member, env)) {
        return respond(i, ephemeral('⛔ Cette commande ne peut être utilisée que dans un ticket que vous possédez, ou par le staff.'));
      }
      const r = await closeTicket(i.channel, i.user);
      if (!r.ok) return respond(i, ephemeral('❌ Ce salon n\'est pas un ticket.'));
      return respond(i, ephemeral('🔒 Ticket en cours de fermeture.'));
    },

    async bug(i) {
      const description = i.options.getString('description', true);
      const etapes = i.options.getString('etapes') ?? '*Non précisé*';
      const sent = await sendLog(i.guild, 'bot', { color: Color.warn, title: '🐞 Nouveau bug', description: truncate(description, 1000),
        fields: [{ name: 'Étapes', value: truncate(etapes, 1000) }, { name: 'Auteur', value: `${i.user} (${i.user.id})` }] });
      return respond(i, ephemeral(sent ? '✅ Merci, votre bug a été transmis au staff.' : '✅ Merci pour le signalement.'));
    },

    async suggestion(i) {
      const idea = i.options.getString('idee', true);
      const ch = i.guild.channels.cache.find((c) => c.name.includes('suggestions'));
      const msg = await safe(() => ch?.send({ embeds: [{ color: Color.info, title: '💡 Suggestion', description: truncate(idea, 1500), footer: { text: `Proposé par ${i.user.username}` }, timestamp: new Date().toISOString() }] }));
      if (msg) { await safe(() => msg.react('👍')); await safe(() => msg.react('👎')); }
      return respond(i, ephemeral(msg ? '💡 Merci pour votre idée !' : '❌ Impossible d\'enregistrer la suggestion.'));
    },

    async report(i) {
      const target = i.options.getUser('membre', true);
      const motif = i.options.getString('motif', true);
      if (target.id === i.user.id) return respond(i, ephemeral('🤔 Vous ne pouvez pas vous signaler vous-même.'));
      const sent = await sendLog(i.guild, 'moderation', { color: Color.warn, title: '🚨 Signalement', fields: [
        { name: 'Signalé', value: `${target} (${target.id})`, inline: true },
        { name: 'Par', value: `${i.user} (${i.user.id})`, inline: true },
        { name: 'Motif', value: truncate(motif, 1000) },
      ] });
      return respond(i, ephemeral(sent ? '✅ Signalement transmis au staff.' : '❌ Impossible de transmettre le signalement.'));
    },

    async warn(i) {
      if (!staffOnly(i, env)) return;
      const target = i.options.getUser('membre', true);
      const reason = i.options.getString('raison') ?? 'Non précisé';
      const count = store.addWarn(target.id, { reason, by: i.user.id, at: Date.now() });
      await sendLog(i.guild, 'moderation', { color: Color.warn, title: '⚠️ Avertissement', fields: [
        { name: 'Membre', value: `${target} (${target.id})`, inline: true },
        { name: 'Staff', value: `${i.user}`, inline: true },
        { name: 'Motif', value: truncate(reason, 1000) },
        { name: 'Total', value: String(count), inline: true },
      ] });
      await safe(() => target.send({ embeds: [{ color: Color.warn, title: '⚠️ Avertissement', description: `Vous avez reçu un avertissement sur **${i.guild.name}**.\nMotif : ${truncate(reason, 500)}` }] }));
      return respond(i, ephemeral(`⚠️ ${target.username} a été averti (${count} avertissement(s)).`));
    },

    async clear(i) {
      if (!staffOnly(i, env)) return;
      const n = i.options.getInteger('nombre', true);
      const wait = cooldown.take(`clear:${i.channel.id}`);
      if (wait) return respond(i, ephemeral(`⏳ Patientez ${Math.ceil(wait / 1000)} s avant de recommencer.`));
      await i.deferReply({ flags: EPHEMERAL });
      const deleted = await safe(() => i.channel.bulkDelete(n, true), null);
      const count = deleted?.size ?? 0;
      await sendLog(i.guild, 'messages', { color: Color.danger, title: '🗑️ Messages supprimés', description: `${count} message(s) supprimé(s) dans ${i.channel} par ${i.user}.` });
      return respond(i, ephemeral(`🗑️ ${count} message(s) supprimé(s).`));
    },

    async setup(i) {
      if (i.user.id !== env.ownerId && !i.member.permissions.has('Administrator')) {
        return respond(i, ephemeral('⛔ Réservé à l\'administrateur du serveur.'));
      }
      const wait = cooldown.take(`setup:${i.guild.id}`);
      if (wait) return respond(i, ephemeral('⏳ Un setup a été lancé il y a peu. Réessayez plus tard.'));
      await i.deferReply({ flags: EPHEMERAL });
      const r = await runSetup(i.guild, { env, reason: `Setup par ${i.user.tag ?? i.user.id}` });
      return respond(i, ephemeral(
        `✅ Setup terminé.\nRôles créés : ${r.roles} • Catégories : ${r.categories} • Salons : ${r.channels} • Messages : ${r.messages}\n` +
        `Éléments déjà présents (ignorés) : ${r.skipped}` + (r.errors.length ? `\n⚠️ Erreurs : ${r.errors.join(', ')}` : ''),
      ));
    },
  };
}

/** Routage : retourne true si l'interaction a été gérée. */
export async function dispatchCommand(i, handlers) {
  if (!i.isChatInputCommand() || !ALL_NAMES.includes(i.commandName)) return false;
  const fn = handlers[i.commandName];
  try {
    await fn(i);
  } catch (e) {
    log.error(`Commande /${i.commandName} :`, e);
    await respond(i, ephemeral('❌ Une erreur est survenue. Le staff a été prévenu.'));
  }
  return true;
}
