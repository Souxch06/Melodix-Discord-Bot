import { test } from 'node:test';
import assert from 'node:assert/strict';
import { loadEnv } from '../src/config/env.js';
import { coreName, ticketSlug, truncate } from '../src/utils/text.js';
import { redact, configureLogger } from '../src/utils/logger.js';
import { createCooldown } from '../src/utils/cooldown.js';
import { buildMessages, hasRef } from '../src/config/messages.js';
import { ALL_CHANNELS, ROLES } from '../src/config/layout.js';

const ok = { DISCORD_TOKEN: 'x'.repeat(10), CLIENT_ID: '123456789012345678', GUILD_ID: '223456789012345678', OWNER_ID: '323456789012345678' };

test('env: variables requises', () => {
  assert.throws(() => loadEnv({}), /DISCORD_TOKEN/);
  assert.throws(() => loadEnv({ ...ok, GUILD_ID: 'abc' }), /invalides/);
  assert.equal(loadEnv(ok).guildId, ok.GUILD_ID);
});

test('logger: masque les secrets et les tokens', () => {
  configureLogger({ secrets: ['supersecret123'] });
  assert.equal(redact('a supersecret123 b'), 'a [REDACTED] b');
  assert.ok(!redact('MTIzNDU2Nzg5MDEyMzQ1Njc4.AbCdEf.abcdefghijklmnopqrstuvwxyz1').includes('MTIz'));
});

test('texte: noms de salons et slugs', () => {
  assert.equal(coreName('🎫│ouvrir-un-ticket'), 'ouvrir-un-ticket');
  assert.equal(ticketSlug('Éric  Dupont!!'), 'eric-dupont');
  assert.equal(ticketSlug('!!!'), 'membre');
  assert.equal(truncate('abcdef', 4), 'abc…');
});

test('cooldown: bloque puis autorise', () => {
  let t = 0;
  const c = createCooldown(1000, () => t);
  assert.equal(c.take('k'), 0);
  assert.ok(c.take('k') > 0);
  t = 1500;
  assert.equal(c.take('k'), 0);
});

test('embeds: chaque message a une référence unique', () => {
  const m = buildMessages({ links: {} });
  const refs = Object.values(m).map((p) => p.embeds?.[0]?.footer?.text ?? '');
  assert.equal(new Set(refs).size, refs.length);
  assert.ok(hasRef({ embeds: [{ footer: { text: 'Melodix • ref:rules' } }] }, 'rules'));
});

test('layout: rôles et salons uniques (idempotence)', () => {
  const names = ROLES.map((r) => r.name);
  assert.equal(new Set(names).size, names.length);
  const chans = ALL_CHANNELS.map((c) => coreName(c.name) + c.type);
  assert.equal(new Set(chans).size, chans.length);
  assert.equal(ROLES.length, 17);
});
