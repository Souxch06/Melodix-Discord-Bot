// Enregistre les commandes slash sur le serveur de test (GUILD_ID). Ignore l'appel si rien n'a changé.
import 'dotenv/config';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { REST, Routes } from 'discord.js';
import { commandDefinitions } from '../src/commands/definitions.js';
import { loadEnv } from '../src/config/env.js';

export async function registerCommands(env, { force = false } = {}) {
  const body = JSON.stringify(commandDefinitions);
  const hash = createHash('sha256').update(body).digest('hex');
  const hashFile = path.join(env.dataDir, 'commands.hash');
  try {
    if (!force && readFileSync(hashFile, 'utf8') === hash) return { skipped: true };
  } catch { /* pas encore enregistré */ }

  const rest = new REST({ version: '10' }).setToken(env.token);
  await rest.put(Routes.applicationGuildCommands(env.clientId, env.guildId), { body: commandDefinitions });
  mkdirSync(env.dataDir, { recursive: true });
  writeFileSync(hashFile, hash);
  return { skipped: false, count: commandDefinitions.length };
}

if (process.argv[1] && process.argv[1].endsWith('deploy-commands.js')) {
  const env = loadEnv();
  registerCommands(env, { force: true })
    .then((r) => console.log(`Commandes enregistrées : ${r.count}`))
    .catch((e) => { console.error('Échec :', e.message); process.exit(1); });
}
