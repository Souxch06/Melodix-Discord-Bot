// Vérifie la syntaxe de tous les fichiers JS du projet (sans connexion Discord).
import { execFileSync } from 'node:child_process';
import { readdirSync, statSync } from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const walk = (d) => readdirSync(d).flatMap((f) => {
  if (f === 'node_modules' || f.startsWith('.')) return [];
  const p = path.join(d, f);
  return statSync(p).isDirectory() ? walk(p) : p.endsWith('.js') ? [p] : [];
});
let failed = 0;
for (const f of walk(root)) {
  try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); }
  catch (e) { failed++; console.error(`✗ ${path.relative(root, f)}\n${e.stderr}`); }
}
console.log(failed ? `${failed} fichier(s) en erreur` : 'Syntaxe OK');
process.exit(failed ? 1 : 0);
